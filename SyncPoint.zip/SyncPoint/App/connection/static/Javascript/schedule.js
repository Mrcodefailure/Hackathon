const homeBtn = document.getElementById("home"); // Getting Element with id 'home'
const settings = document.getElementById("settings");
const person = document.getElementById("person");
const whitescreen = document.getElementById("whitescreen");
  
settings.onclick = function() {
    settings.style.zIndex = "300";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
    setTimeout(() => {
        settings.style.opacity = "0";
        settings.style.transition = "opacity 0.3s ease";
    }, 700);
    
    // Add class for settings icon transition
    settings.classList.add('expand');
    settings.classList.add('rotating');
  
    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../settings');
    }, 1000); // Match transition time for smooth effect
};
  
homeBtn.onclick = function() {
    homeBtn.style.zIndex = "300";
    person.style.zIndex = "301";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
    setTimeout(() => {
        homeBtn.style.opacity = "0";
        person.style.opacity = "0";
        homeBtn.style.transition = "opacity 0.3s ease";
        person.style.transition = "opacity 0.3s ease";
    }, 800);
    
    // Add class for home icon transition
    homeBtn.classList.add('expand');
    setTimeout(() => {
      person.classList.add("visible");
    }, 200);
  
    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../');
    }, 1000); // Match transition time for smooth effect
};
