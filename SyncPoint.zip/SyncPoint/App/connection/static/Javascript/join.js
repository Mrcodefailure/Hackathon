const joinElement = document.getElementById("join"); // Getting HTML Element with id 'join'
const homeBtn = document.getElementById("home");
const settings = document.getElementById("settings");
const person = document.getElementById("person");
const whitescreen = document.getElementById("whitescreen");
const covering = document.getElementById("covering");
const descriptionBtn = document.getElementById("description");
const description = document.getElementById("actual-description");
const topper = document.getElementById("topper");
const camera = document.getElementById("camera");
const mic = document.getElementById("mic");
const speaker = document.getElementById("speaker");
const cameraDiv = document.getElementById('cameraDiv');
const messages = ["Joining.", "Joining..", "Joining..."]; // Set of Recurring Messages
let i = 0;
let videoStream = null;
let audioStream = null;
let isDeafened = false;
let localStream, peerConnection;

const cameraOn = "/static/Source/Video.svg";
const cameraOff = "/static/Source/CameraOff.svg";
const micOn = "/static/Source/Mic.svg";
const micOff = "/static/Source/MicrophoneOff.svg";
const speakerOn = "/static/Source/Speaker.svg";
const speakerOff = "/static/Source/SpeakerOff.svg";

function toggleButton(buttonElement, onSrc, offSrc) {
    const imgElement = buttonElement.querySelector('img');
    const currentState = buttonElement.getAttribute('data-state');
    imgElement.src = currentState === 'off' ? onSrc : offSrc;
    buttonElement.setAttribute('data-state', currentState === 'off' ? 'on' : 'off');
    buttonElement.style.backgroundColor = currentState === 'off' ? 'lightgreen' : 'red';
};

// Event listeners for toggling camera, mic, and speaker
camera.addEventListener('click', () => {
    toggleButton(camera, cameraOn, cameraOff);
    handleCameraStream();
});

mic.addEventListener('click', () => {
    toggleButton(mic, micOn, micOff);
    handleMicStream();
});

speaker.addEventListener('click', () => {
    toggleButton(speaker, speakerOn, speakerOff);
    manageAudioTracks();
});

function manageAudioTracks() {
  if (audioStream) {
      audioStream.getAudioTracks().forEach(track => {
          track.enabled = !isDeafened; 
      });
      console.log(`You are ${isDeafened ? 'deafened' : 'undeafened'}.`);
  }
}

async function handleMicStream() {
  try {
      const conditionMic = mic.dataset.state === 'on';
      if (conditionMic) {
          if (!audioStream) {
              audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
              console.log("Microphone is on.");
              // Create audio element for playback
              const audioElement = document.createElement('audio');
              audioElement.srcObject = audioStream;
              audioElement.autoplay = true;
              audioElement.controls = false;
              audioElement.style.display = 'none';
              document.body.appendChild(audioElement);
          }
      } else {
          if (audioStream) {
              audioStream.getTracks().forEach(track => track.stop());
              audioStream = null;
              console.log("Microphone is off.");
          }
      }
  } catch (error) {
      console.error('Error accessing the microphone.', error);
  }
}

async function handleCameraStream() {
  const conditionCamera = camera.dataset.state === 'on';

  try {
      if (conditionCamera) {
          if (!videoStream) {
              videoStream = await navigator.mediaDevices.getUserMedia({ video: true });
              const video = document.createElement('video');
              video.srcObject = videoStream;
              video.autoplay = true;
              video.style.width = '100%';
              video.style.height = '100%';
              cameraDiv.innerHTML = ''; // Clear previous video element
              cameraDiv.appendChild(video);
              console.log("Camera is on.");
          }
      } else {
          if (videoStream) {
              videoStream.getTracks().forEach(track => track.stop());
              videoStream = null;
              cameraDiv.innerHTML = ''; 
              console.log("Camera is off.");
          }
      }
  } catch (error) {
      console.error('Error accessing the camera.', error);
  }
}

// Run this function on page load to reset both the camera and microphone
window.onload = () => {
  mic.dataset.state = 'off';
  camera.dataset.state = 'off';
};

function updateJoinText() {
  joinElement.innerText = messages[i]; // Changing Inner Text of join button to recurring messages
  joinElement.title = messages[i]; // Same with title
  i = (i + 1) % messages.length; // Eg: 1 => (1+1) % 3 = 2
}

joinElement.onclick = function () { // When Button is clicked,
  // Set the opacity to 0.5 gradually using CSS transition
  joinElement.innerHTML = ''; // Clear inner HTML
  joinElement.style.transition = "all 0.3s ease"; // Setting Transition
  joinElement.style.opacity = 0.5; // Make it semi-transparent
  joinElement.style.width = "160px";
  joinElement.style.height = "90px";
  joinElement.style.fontSize = "35px";
  joinElement.style.borderRadius = "5px";
  joinElement.style.transformOrigin = "center";

  // Add the 'clicked' class to prevent hover effects
  joinElement.classList.add("clicked");

  window.location.replace('../meetingroom')

  // Call the function to update the text in intervals
  setInterval(updateJoinText, 500);
};

settings.onclick = function() {
  settings.style.zIndex = "300";
  whitescreen.style.pointerEvents = "auto";
  whitescreen.style.opacity = "1";
  whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
  setTimeout(() => {
      settings.style.opacity = "0";
      settings.style.transition = "opacity 0.3s ease";
  }, 700);
  
  // Add class for settings icon transition
  settings.classList.add('expand');
  settings.classList.add('rotating');

  // Transition delay for whitescreen
  setTimeout(() => {
      window.location.replace('../settings');
  }, 1000); // Match transition time for smooth effect
};

homeBtn.onclick = function() {
  homeBtn.style.zIndex = "300";
  person.style.zIndex = "301";
  whitescreen.style.pointerEvents = "auto";
  whitescreen.style.opacity = "1";
  whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
  setTimeout(() => {
      homeBtn.style.opacity = "0";
      person.style.opacity = "0";
      homeBtn.style.transition = "opacity 0.3s ease";
      person.style.transition = "opacity 0.3s ease";
  }, 800);
  
  // Add class for home icon transition
  homeBtn.classList.add('expand');
  setTimeout(() => {
    person.classList.add("visible");
  }, 200);

  // Transition delay for whitescreen
  setTimeout(() => {
      window.location.replace('../');
  }, 1000); // Match transition time for smooth effect
};

descriptionBtn.onclick = function() {
  covering.style.pointerEvents = "auto";
  covering.style.backgroundColor = "rgba(0, 0, 0, 0.4)";
  covering.style.transition = "all 0.3s ease";
  description.style.pointerEvents = "auto";
  description.style.transform = "scale(1)";
  description.style.transition = "all 0.3s ease";
  topper.style.pointerEvents = "auto";
  topper.style.transform = "scale(1)";
  topper.style.transition = "all 0.3s ease";
  topper.style.top = "12.5vh";
  topper.style.left = "14.3vw";
};

covering.onclick = function() {
  covering.style.pointerEvents = "none";
  covering.style.backgroundColor = "rgba(0, 0, 0, 0)"
  covering.style.transition = "all 0.3s ease";
  description.style.pointerEvents = "none";
  description.style.transform = "scale(0)";
  description.style.transition = "all 0.3s ease";
  topper.style.pointerEvents = "none";
  topper.style.transform = "scale(0)";
  topper.style.transition = "all 0.3s ease";
  topper.style.top = "50%";
};

window.onresize = function() {
  let joinSize = Math.min(window.innerWidth * 0.12, 100); // Adjust size based on viewport
  document.querySelector('.join').style.width = joinSize + 'px';
  document.querySelector('.join').style.height = joinSize + 'px';
  document.querySelector('.join').style.fontSize = (joinSize / 2) + 'px';
};
