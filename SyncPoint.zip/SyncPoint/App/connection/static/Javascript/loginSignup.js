const homeBtn = document.getElementById("home"); // Getting Element with id 'home'
const settings = document.getElementById("settings");
const person = document.getElementById("person");
const whitescreen = document.getElementById("whitescreen");
const checkbox = document.getElementById("show-password");
const password = document.getElementById("login-password");
const secondCheckbox = document.getElementById("showsecondpassword");
const passwordAnother = document.getElementById("signup-password");
const passwordConfirm = document.getElementById("password-confirm");
const signup = document.getElementById("sign-up");
const formDivLogIn = document.getElementById("form-login");
const divSignUp = document.getElementById("signUp");
const formDivSignUp = document.getElementById("form-signup");
const divLogIn = document.getElementById("logIn");
const login = document.getElementById("log-in");
const signupForm = document.getElementById('signup-form');
const loginForm = document.getElementById('login-form');


// Signup function
signupForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('password-confirm').value;

    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    fetch('http://localhost:8000/signup', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message) {
            alert(data.message);
        } else {
            alert('Signup failed');
        }
    })
    .catch(error => console.error('Error:', error));
});

// Login function
loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    fetch('http://localhost:8000/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === "Login successful!") {
            alert('Login successful');
            // Redirect or perform any other action here
        } else {
            alert('Login failed');
        }
    })
    .catch(error => console.error('Error:', error));
});

window.onload = function() {
    secondCheckbox.checked = false; // Make sure both the checkboxes are unchecked
    checkbox.checked = false;
};
  
settings.onclick = function() {
    settings.style.zIndex = "300";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease";
    setTimeout(() => {
        settings.style.opacity = "0";
        settings.style.transition = "opacity 0.3s ease";
    }, 700);
    
    // Add class for settings icon transition
    settings.classList.add('expand');
    settings.classList.add('rotating');
  
    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../settings');
    }, 1000); // Match transition time for smooth effect
};
  
homeBtn.onclick = function() {
    homeBtn.style.zIndex = "300";
    person.style.zIndex = "301";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease";
    setTimeout(() => {
        homeBtn.style.opacity = "0";
        person.style.opacity = "0";
        homeBtn.style.transition = "opacity 0.3s ease";
        person.style.transition = "opacity 0.3s ease";
    }, 800);
    
    // Add class for home icon transition
    homeBtn.classList.add('expand');
    setTimeout(() => {
      person.classList.add("visible");
    }, 200);
  
    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../');
    }, 1000); // Match transition time for smooth effect
};

checkbox.addEventListener('change', function() {
    if (checkbox.checked) {
      onCheck();
    } else {
      onUncheck();
    }
});
  
function onCheck() {
    password.type = "text";
};

function onUncheck() {
    password.type = "password";
};

signup.onclick = function() {
    formDivLogIn.style.opacity = "0";
    formDivLogIn.style.transform = "translateX(-50vw)";
    formDivLogIn.style.transition = "all 0.5s ease-out 0.5s";
    divSignUp.style.opacity = "0";
    divSignUp.style.transform = "translateX(-50vw)";
    divSignUp.style.transition = "all 0.5s ease-out 0.5s";
    formDivSignUp.style.opacity = "1";
    formDivSignUp.style.transform = "translateX(50vw)";
    formDivSignUp.style.transition = "all 0.5s ease-out 0.5s";
    divLogIn.style.opacity = "1";
    divLogIn.style.transform = "translateX(50vw)";
    divLogIn.style.transition = "all 0.5s ease-out 0.5s";
};

login.onclick = function() {
    formDivLogIn.style.opacity = "1";
    formDivLogIn.style.transform = "translateX(0vw)";
    formDivLogIn.style.transition = "all 0.5s ease-out 0.5s";
    divSignUp.style.opacity = "1";
    divSignUp.style.transform = "translateX(0vw)";
    divSignUp.style.transition = "all 0.5s ease-out 0.5s";
    formDivSignUp.style.opacity = "0";
    formDivSignUp.style.transform = "translateX(-50vw)";
    formDivSignUp.style.transition = "all 0.5s ease-out 0.5s";
    divLogIn.style.opacity = "0";
    divLogIn.style.transform = "translateX(-50vw)";
    divLogIn.style.transition = "all 0.5s ease-out 0.5s";
}

secondCheckbox.addEventListener('change', function() {
    if (secondCheckbox.checked) {
      onChecker();
    } else {
      onUnchecker();
    }
});
  
function onChecker() {
    passwordAnother.type = "text";
    passwordConfirm.type = "text";
};

function onUnchecker() {
    passwordAnother.type = "password";
    passwordConfirm.type = "password";
};

