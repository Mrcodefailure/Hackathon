const filter = document.getElementById("filter");
const sort = document.getElementById("sort");
const homeBtn = document.getElementById("home");
const settings = document.getElementById("settings");
const person = document.getElementById("person");
const whitescreen = document.getElementById("whitescreen");
const image = document.querySelector(".image-class");
const creator = document.getElementById('creator');
const backgroundCreator = document.getElementById('background');
const meetingName = document.getElementById('meeting-name').value;
const creatorName = document.getElementById('creator-name').value;
const meetingconfirm = document.querySelector('.confirm');
const meetingbtn = document.getElementById('enterMeeting');
let roomcodeEnter = document.getElementById('roomCodeEnter').value;

meetingbtn.addEventListener('click', () => {
    window.location.replace(`../join/${roomcodeEnter}`)
});

filter.onmouseover = function() {
    filter.style.width = "75%";
    filter.style.transition = "all 0.5s ease";
    sort.style.transition = "all 0.5s ease"
    sort.style.width = "25%";
};

filter.onmouseout = function() {
    filter.style.width = "50%";
    filter.style.transition = "all 0.5s ease";
    sort.style.transition = "all 0.5s ease"
    sort.style.width = "50%";
};

sort.onmouseover = function() {
    filter.style.width = "25%";
    filter.style.transition = "all 0.5s ease";
    sort.style.transition = "all 0.5s ease"
    sort.style.width = "75%";
};

sort.onmouseout = function() {
    filter.style.width = "50%";
    filter.style.transition = "all 0.5s ease";
    sort.style.transition = "all 0.5s ease"
    sort.style.width = "50%";
};

function addItem() {
    // Get the container where items will be added
    const container = document.querySelector(".boxes");
    
    // Ask for all the details which can be inserted into the div
    backgroundCreator.style.pointerEvents = 'auto';
    backgroundCreator.style.transition = 'all 0.5s ease';
    creator.style.opacity = '1';
    creator.style.transform = 'scale(1)';
    creator.style.transition = 'all 0.5s ease';
    backgroundCreator.style.opacity = '0.4';
    creator.setAttribute('data-state', 'on');
    creatorState = creator.getAttribute('data-state');

    backgroundCreator.addEventListener('click', () => {
        if (creatorState === 'on') {
            backgroundCreator.style.opacity = '0';
            backgroundCreator.style.pointerEvents = 'none';
            backgroundCreator.style.transition = 'all 0.5s ease';
            creator.style.transform = 'scale(0)';
            creator.style.transition = 'all 0.5s ease';
            creator.setAttribute('data-state', 'off');
        }
        else {
            backgroundCreator.style.opacity = '0.4';
            backgroundCreator.style.pointerEvents = 'auto';
            backgroundCreator.style.transition = 'all 0.5s ease'
            creator.style.transform = 'scale(1)';
            creator.style.transition = 'all 0.5s ease'
            creator.setAttribute('data-state', 'on');
        }
    })
    meetingconfirm.addEventListener('click', () => {
        // Create a new div for the item
        const newItem = document.createElement('div');
        const img = document.createElement('img');
        const heading = document.createElement('h4');
        const paraCreator = document.createElement('p');
        const joinMeeting = document.createElement('button');

        // Set content and attributes for the elements
        img.src = "https://via.placeholder.com/150";
        img.classList.add("image-class");

        heading.textContent = meetingName;
        paraCreator.textContent = creatorName;

        joinMeeting.textContent = "Join";
        joinMeeting.onclick = function() {
            window.location.replace('../meetingroom');
        };

        // Append all child elements to the new item div
        newItem.appendChild(img);
        newItem.appendChild(heading);
        newItem.appendChild(paraCreator);
        newItem.appendChild(joinMeeting);

        // Set the class and style for the new item
        newItem.classList.add('classroom');

        // Random background color
        const items = ['red', 'blue', 'pink', 'orange', 'green', 'black', 'white', 'yellow'];
        const randomIndex = Math.floor(Math.random() * items.length);
        const randomColor = items[randomIndex];

        newItem.style.backgroundColor = randomColor;
        newItem.style.margin = "20px";
        newItem.style.borderRadius = "10px";
        newItem.style.border = "none";
        newItem.style.padding = "10px"; // Add some padding for better layout
        newItem.style.display = 'grid';
        img.style.alignSelf = "center";
        heading.style.justifySelf = 'center';
        newItem.style.margin = '10px';

        // Adjust text color and border for specific background colors
        if (randomColor === "black") {
            newItem.style.color = "white";
        } else if (randomColor === "white") {
            newItem.style.border = "1px solid black";
        }

        // Append the new item to the container
        container.appendChild(newItem);

        backgroundCreator.style.opacity = '0';
        backgroundCreator.style.pointerEvents = 'none';
        backgroundCreator.style.transition = 'all 0.5s ease';
        creator.style.transform = 'scale(0)';
        creator.style.transition = 'all 0.5s ease';
        creator.setAttribute('data-state', 'off');
        heading.textContent = '';
        paraCreator.textContent = '';

        window.addEventListener('scroll', () => {
            backgroundCreator.style.position = 'fixed';
            creator.style.position = 'fixed';
        });

        window.addEventListener('stalled', () => {
            backgroundCreator.style.position = 'absolute';
            creator.style.position = 'absolute';
        });
    })
};
  
settings.onclick = function() {
    settings.style.zIndex = "300";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
    // Add class for settings icon transition
    settings.classList.add('expand');
    settings.classList.add('rotating');

    setTimeout(() => {
        settings.style.opacity = "0";
        settings.style.transition = "opacity 0.3s ease";
    }, 700);
  
    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../settings');
    }, 1000); // Match transition time for smooth effect
};
  
homeBtn.onclick = function() {
    homeBtn.style.zIndex = "300";
    person.style.zIndex = "301";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
    
    // Add class for home icon transition
    homeBtn.classList.add('expand');
    setTimeout(() => {
      person.classList.add("visible");
    }, 200);
  
    setTimeout(() => {
        homeBtn.style.opacity = "0";
        person.style.opacity = "0";
        homeBtn.style.transition = "opacity 0.3s ease";
        person.style.transition = "opacity 0.3s ease";
    }, 800);

    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../');
    }, 1000); // Match transition time for smooth effect
};
