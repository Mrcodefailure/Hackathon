const homeBtn = document.getElementById("home"); // Getting Element with id 'home'
const person = document.getElementById("person");
const whitescreen = document.getElementById("whitescreen");
const inputOutput = document.querySelector('.input-output');
const permissions = document.querySelector('.permissions');
const account = document.querySelector('.account');
const settingsIO = document.getElementById('input-output-settings');
const settingsPerm = document.getElementById('permissions-settings');
const settingsAcc = document.getElementById('account-settings');

  
homeBtn.onclick = function() {
    homeBtn.style.zIndex = "300";
    person.style.zIndex = "301";
    whitescreen.style.pointerEvents = "auto";
    whitescreen.style.opacity = "1";
    whitescreen.style.transition = "opacity 0.3s ease"; // Transition for opacity
    setTimeout(() => {
        homeBtn.style.opacity = "0";
        person.style.opacity = "0";
        homeBtn.style.transition = "opacity 0.3s ease";
        person.style.transition = "opacity 0.3s ease";
    }, 800);
    
    // Add class for home icon transition
    homeBtn.classList.add('expand');
    setTimeout(() => {
      person.classList.add("visible");
    }, 200);
  
    // Transition delay for whitescreen
    setTimeout(() => {
        window.location.replace('../');
    }, 1000); // Match transition time for smooth effect
};

account.onclick = function() {
    settingsAcc.style.opacity = "1";
    settingsAcc.style.display = "flex";
    settingsPerm.style.opacity = "0";
    settingsPerm.style.display = "none";
    settingsIO.style.opacity = "0";
    settingsIO.style.display = "none";
};

permissions.onclick = function() {
    settingsPerm.style.opacity = "1";
    settingsPerm.style.display = "flex";
    settingsAcc.style.opacity = "0";
    settingsAcc.style.display = "none";
    settingsIO.style.opacity = "0";
    settingsIO.style.display = "none";
};

inputOutput.onclick = function() {
    settingsIO.style.opacity = "1";
    settingsIO.style.display = "flex";
    settingsAcc.style.opacity = "0";
    settingsAcc.style.display = "none";
    settingsPerm.style.opacity = "0";
    settingsPerm.style.display = "none";
};
